import type { VercelRequest, VercelResponse } from '@vercel/node';
import { method, requireOwnedRun, respondError, tenantContext } from '../../server/runtime.js';

export default async function handler(req: VercelRequest, res: VercelResponse): Promise<void> {
  if (!method(req, res, ['GET'])) return;
  try {
    const context = await tenantContext(req);
    const id = String(req.query.runId ?? '');
    const pollOnly = String(req.query.poll ?? '') === '1';
    await requireOwnedRun(context, id);
    const runQuery = pollOnly
      ? context.db.from('generation_runs').select('id,state,current_stage,error,created_at,updated_at,requested_entry_count').eq('id', id).eq('tenant_id', context.tenantId).eq('user_id', context.userId).single()
      : context.db.from('generation_runs').select('*').eq('id', id).eq('tenant_id', context.tenantId).eq('user_id', context.userId).single();
    const run = await runQuery;
    if (run.error) throw run.error;
    const stagesQuery = pollOnly
      ? context.db.from('engine_stage_runs').select('id,stage,version,status,warnings,errors,created_at,completed_at').eq('tenant_id', context.tenantId).eq('generation_run_id', id).order('created_at', { ascending: true })
      : context.db.from('engine_stage_runs').select('*').eq('tenant_id', context.tenantId).eq('generation_run_id', id).order('created_at', { ascending: true });
    const stages = await stagesQuery;
    if (stages.error) throw stages.error;
    if (pollOnly) { res.status(200).json({ run: run.data, stages: stages.data ?? [], lineups: [] }); return; }
    const selection = await context.db.from('floyd_dfs_selection_runs').select('id,version,status,created_at,floyd_dfs_generated_lineups(*)').eq('tenant_id', context.tenantId).eq('generation_run_id', id).order('created_at', { ascending: false }).limit(1).maybeSingle();
    if (selection.error) throw selection.error;
    const trust = await context.db.from('floyd_dfs_run_trust').select('revision,trust_payload,created_at').eq('tenant_id', context.tenantId).eq('generation_run_id', id).order('revision', { ascending: false }).limit(1).maybeSingle();
    if (trust.error) throw trust.error;
    const traces = await context.db.from('floyd_dfs_lineup_decision_traces').select('lineup_candidate_key,trace_payload,content_sha256').eq('tenant_id', context.tenantId).eq('generation_run_id', id);
    if (traces.error) throw traces.error;
    const lineage = await context.db.from('floyd_dfs_generation_run_lineage').select('*').eq('tenant_id', context.tenantId).eq('generation_run_id', id).order('revision', { ascending: false }).limit(1).maybeSingle();
    if (lineage.error) throw lineage.error;
    const projectionArtifacts = lineage.data
      ? await context.db.from('floyd_dfs_run_projection_artifacts').select('*').eq('tenant_id', context.tenantId).eq('generation_run_id', id).eq('lineage_revision', lineage.data.revision).order('artifact_type', { ascending: true })
      : { data: [], error: null };
    if (projectionArtifacts.error) throw projectionArtifacts.error;
    const lineupRevisions = await context.db.from('floyd_dfs_lineup_revisions').select('*').eq('tenant_id', context.tenantId).eq('generation_run_id', id).order('generated_at', { ascending: true });
    if (lineupRevisions.error) throw lineupRevisions.error;
    res.status(200).json({ run: run.data, stages: stages.data ?? [], lineups: selection.data?.floyd_dfs_generated_lineups ?? [], trust: trust.data ?? null, decisionTraces: traces.data ?? [], lineage: lineage.data ?? null, projectionArtifacts: projectionArtifacts.data ?? [], lineupRevisions: lineupRevisions.data ?? [] });
  } catch (error) { respondError(req, res, error); }
}

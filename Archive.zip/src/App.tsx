import { BrowserRouter, Routes, Route, useLocation } from 'react-router-dom'
import Navigation from './components/Navigation'
import { SportsNewsTicker } from './components/SportsNewsTicker'
import ScanPage from './pages/ScanPage'
import HistoryPage from './pages/HistoryPage'
import RunPage from './pages/RunPage'
import ResearchPage from './pages/ResearchPage'
import LearningPage from './pages/LearningPage'
import DesignSystem from './pages/DesignSystem'
import AdminConsole from './pages/admin/AdminConsole'
import StreetTeamPage from './pages/StreetTeamPage'
import NbaHousePage from './pages/NbaHousePage'
import OperationsPage from './pages/OperationsPage'
import { ToastProvider } from './components/ToastProvider'
import { useEnterTransition } from './hooks/useEnterTransition'
import { ErrorBoundary } from './components/ErrorBoundary'
import { AdminGuard } from './components/AdminGuard'
import { SignInGate } from './components/SignInGate'

function RouteFade({ children }: { children: React.ReactNode }) {
  const location = useLocation()
  const entered = useEnterTransition([location.pathname])

  return (
    <div
      className={`transition-opacity duration-[var(--transition-default)] ${
        entered ? 'opacity-100' : 'opacity-0'
      }`}
    >
      {children}
    </div>
  )
}

function App() {
  return (
    <SignInGate><BrowserRouter>
      <ToastProvider>
        <ErrorBoundary>
          <SportsNewsTicker />
          <Navigation />
          <RouteFade>
            <Routes>
              <Route path="/" element={<ScanPage />} />
              <Route path="/lineup-lab" element={<ScanPage />} />
              <Route path="/street-team" element={<StreetTeamPage />} />
              <Route path="/house/nba" element={<NbaHousePage />} />
              <Route path="/history" element={<HistoryPage />} />
              <Route path="/runs/:runId" element={<RunPage />} />
              <Route path="/research/:runId" element={<ResearchPage />} />
              <Route path="/learning" element={<LearningPage />} />
              <Route
                path="/operations"
                element={
                  <AdminGuard>
                    <OperationsPage />
                  </AdminGuard>
                }
              />
              <Route
                path="/admin/design-system"
                element={
                  <AdminGuard>
                    <AdminConsole>
                      <DesignSystem />
                    </AdminConsole>
                  </AdminGuard>
                }
              />
            </Routes>
          </RouteFade>
        </ErrorBoundary>
      </ToastProvider>
    </BrowserRouter></SignInGate>
  )
}

export default App

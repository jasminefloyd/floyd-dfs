import type { LineupCandidate, OptimizerPackage, PortfolioConstraints, ResearchPackage, SelectedLineup, SelectionPackage, SlatePlayer, ValidatedSlate } from './contracts.js';
import { calibratedCashLineProbability, CASH_LINE_TARGET_PROBABILITY, type CashLineCalibration } from './cashLineCalibration.js';
import { validateLineupCandidate } from './validation.js';

export interface SelectionInput {
  validatedSlate: ValidatedSlate;
  researchPackage: ResearchPackage;
  optimizerPackage: Pick<OptimizerPackage, 'candidates' | 'portfolioConstraints' | 'searchCompleteness' | 'searchDiagnostics'>;
  cashLineCalibration?: CashLineCalibration;
  lockedRosterSlots?: Record<string, string>;
  useFinancialObjective?: boolean;
}

export function selectLineups(input: SelectionInput, now = new Date()): SelectionPackage {
  const seenCandidateIds = new Set<string>();
  const rejected = input.optimizerPackage.candidates.map((candidate) => {
    const errors = validateLineupCandidate(candidate, input.validatedSlate, { lockedSlotAssignments: input.lockedRosterSlots });
    if (seenCandidateIds.has(candidate.id)) errors.push(`candidate identity ${candidate.id} is duplicated.`);
    seenCandidateIds.add(candidate.id);
    return { candidate, errors };
  }).filter((entry) => entry.errors.length > 0);
  const candidates = input.optimizerPackage.candidates.filter((candidate) => !rejected.some((entry) => entry.candidate.id === candidate.id));
  if (!candidates.length) return { slateId: input.validatedSlate.slateId, tenantId: input.validatedSlate.tenantId, sport: input.validatedSlate.sport, version: 1, generatedAt: now.toISOString(), selectedLineups: [], optimizerGap: 'Optimizer returned no candidates for Selection.', warnings: [], status: 'BLOCKED', engineState: 'MODEL_VALIDATION_REQUIRED' };
  const requested = Math.max(1, input.validatedSlate.contest.userEntryCount);
  const maximum = input.validatedSlate.contest.maxEntriesAllowed ?? requested;
  const count = Math.min(requested, maximum);
  const isCashGame = input.validatedSlate.contest.contestKind === 'CASH';
  const ranked = rankForContext(candidates, input.validatedSlate, input.cashLineCalibration, input.useFinancialObjective === true);
  const { selected, underfilled } = choosePortfolio(ranked, count, isCashGame, input.optimizerPackage.portfolioConstraints);
  const warnings = [
    ...(rejected.length ? [`${rejected.length} optimizer candidate(s) were rejected by the authoritative lineup validator; first reason: ${rejected[0].errors[0]}`] : []),
    ...(underfilled ? [`Only ${selected.length} of ${count} requested lineup(s) could be selected; remaining candidates were unavailable or violated portfolio exposure/overlap constraints.`] : []),
    ...(input.optimizerPackage.searchCompleteness === 'BOUNDED' ? [`Optimizer search was bounded after ${input.optimizerPackage.searchDiagnostics?.nodesVisited ?? 'an unknown number of'} nodes; these are the best evaluated candidates, not a proven global optimum.`] : []),
  ];
  const nearDuplicateCount = selected.filter((candidate) => candidate.strategicSimilarity >= 0.8).length;
  if (nearDuplicateCount) warnings.push(`${nearDuplicateCount} of ${selected.length} selected lineups closely overlap (>=80% shared players) with another selected lineup because the candidate pool didn't contain enough sufficiently distinct high-quality builds.`);
  const optimizerGap = input.optimizerPackage.searchCompleteness === 'BOUNDED'
    ? input.optimizerPackage.searchDiagnostics?.objectiveGap !== undefined
      ? `Search was bounded; the best evaluated Max FPTS lineup is up to ${input.optimizerPackage.searchDiagnostics.objectiveGap.toFixed(2)} raw objective points below the admissible slot-wise upper bound.`
      : `Search was bounded after ${input.optimizerPackage.searchDiagnostics?.nodesVisited ?? 'an unknown number of'} nodes; results are the best evaluated candidates, not a proven global optimum.`
    : undefined;
  return { slateId: input.validatedSlate.slateId, tenantId: input.validatedSlate.tenantId, sport: input.validatedSlate.sport, version: 1, generatedAt: now.toISOString(), selectedLineups: selected.map((candidate, index) => explain(candidate, index + 1, input, isCashGame)), ...(optimizerGap ? { optimizerGap } : {}), warnings, status: 'COMPLETE', engineState: 'MODEL_VALIDATION_REQUIRED' };
}

// Default to the deterministic tournament composite. The ownership-weighted opponent-field
// simulation remains diagnostic until an out-of-sample release gate passes, so its win/ROI
// frequencies do not choose lineups.
// Default to the tournament-composite rank (already balances median/ceiling/frequency) — sorting
// by raw median alone is exactly the "always pick highest median" anti-pattern the design docs
// warn against, and it's the wrong objective for a tournament regardless of contest size. The
// one carve-out is a contest DraftKings' own payout structure classifies as a cash game (see
// draftKingsSlate.ts's classifyContestKind) — there, beating the cash line is the actual game
// being played, so candidates are ranked by cash-line probability instead. This never blocks or
// shrinks the portfolio: choosePortfolio always fills from this ranking regardless of whether
// any candidate actually clears the 85% target -- see explain() for how a shortfall is disclosed.
function rankForContext(candidates: LineupCandidate[], slate: ValidatedSlate, calibration: CashLineCalibration | undefined, useFinancialObjective: boolean): LineupCandidate[] {
  if (useFinancialObjective && candidates.every((candidate) => Number.isFinite(candidate.expectedProfit))) return [...candidates].sort((a, b) => b.expectedProfit! - a.expectedProfit!);
  if (slate.contest.objective === 'MAX_FPTS') return [...candidates].sort((a, b) => (b.expectedPoints ?? b.median) - (a.expectedPoints ?? a.median));
  if (slate.contest.contestKind === 'CASH') return [...candidates].sort((a, b) => (cashRankScore(b, slate, calibration) - cashRankScore(a, slate, calibration)));
  // `JOINT_FIELD_SIMULATION` is an unvalidated diagnostic, not an objective input.
  return [...candidates].sort((a, b) => heuristicTournamentRankOf(a) - heuristicTournamentRankOf(b));
}

function cashRankScore(candidate: LineupCandidate, _slate: ValidatedSlate, calibration: CashLineCalibration | undefined): number { return resolveCashLineProbability(candidate, calibration).probability ?? (candidate.expectedPoints ?? candidate.median); }

export interface CashLineResolution { probability?: number; confidence: 'CALIBRATED' | 'SIMULATED_ESTIMATE' | 'UNAVAILABLE'; }
// Probability is exposed only after an explicit calibration release. Raw optimizer simulations
// remain diagnostic and cannot be represented as cash-line or win probabilities.
export function resolveCashLineProbability(candidate: LineupCandidate, calibration: CashLineCalibration | undefined): CashLineResolution {
  if (candidate.cashLineProbability === undefined) return { confidence: 'UNAVAILABLE' };
  if (calibration) { const calibrated = calibratedCashLineProbability(candidate.cashLineProbability, calibration); if (calibrated !== null) return { probability: calibrated, confidence: 'CALIBRATED' }; }
  return { confidence: 'UNAVAILABLE' };
}

// Cash games are probability-based, not a diversity problem: repeating the single best
// cash-line candidate across every entry is the correct play there (see rankForContext), so
// this just takes the top N by rank as-is. `strategicSimilarity` is still computed (against
// already-picked entries) purely for the near-duplicate disclosure in selectLineups/explain.
function canAddToPortfolio(chosen: LineupCandidate[], candidate: LineupCandidate, constraints: PortfolioConstraints | undefined, targetCount: number): boolean {
  if (!constraints?.maxPlayerExposure && !constraints?.maxCaptainExposure && constraints?.maxLineupOverlap === undefined) return true;
  if (constraints?.maxLineupOverlap !== undefined && chosen.some((lineup) => overlap(lineup.playerIds, candidate.playerIds) > constraints.maxLineupOverlap!)) return false;
  const maxPlayer = constraints.maxPlayerExposure !== undefined ? Math.floor(constraints.maxPlayerExposure * targetCount + 1e-9) : Infinity;
  const maxCaptain = constraints.maxCaptainExposure !== undefined ? Math.floor(constraints.maxCaptainExposure * targetCount + 1e-9) : Infinity;
  const playerCounts = new Map<string, number>(); const captainCounts = new Map<string, number>();
  for (const lineup of [...chosen, candidate]) {
    for (const playerId of lineup.playerIds) playerCounts.set(playerId, (playerCounts.get(playerId) ?? 0) + 1);
    const captain = Object.entries(lineup.rosterSlots).find(([slot]) => /(^|_)(CPT|CAPTAIN|MVP)(_|$)/i.test(slot))?.[1]; if (captain) captainCounts.set(captain, (captainCounts.get(captain) ?? 0) + 1);
  }
  return [...playerCounts.values()].every((value) => value <= maxPlayer) && [...captainCounts.values()].every((value) => value <= maxCaptain);
}
function choosePortfolioForCashGame(candidates: LineupCandidate[], count: number, constraints?: PortfolioConstraints): { selected: LineupCandidate[]; underfilled: boolean } {
  const chosen: LineupCandidate[] = [];
  for (const candidate of candidates) {
    if (chosen.length >= count) break;
    if (!canAddToPortfolio(chosen, candidate, constraints, count)) continue;
    const similarity = chosen.length ? Math.max(...chosen.map((existing) => overlap(existing.playerIds, candidate.playerIds))) : 0;
    chosen.push({ ...candidate, strategicSimilarity: similarity });
  }
  return { selected: chosen, underfilled: chosen.length < count };
}

// Greedy diminishing-returns diverse selection for multi-entry GPP portfolios: each pick after
// the first maximizes (rank score - diversityWeight * overlap with the best-matching
// already-chosen lineup), instead of pure rank order. This naturally spreads a portfolio across
// genuinely different captains/stacks/game scripts when the pool supports it, while every
// remaining candidate is still always a legal pick -- so this never returns fewer than `count`
// unless the candidate pool itself is smaller than requested (same guarantee as before; a
// candidate that's still a near-duplicate of everything chosen so far is only picked once it's
// genuinely the best-scoring option left, which is the correct "pool too thin" signal downstream).
const DIVERSITY_WEIGHT = 0.35;
function choosePortfolioDiverse(candidates: LineupCandidate[], count: number, constraints?: PortfolioConstraints): { selected: LineupCandidate[]; underfilled: boolean } {
  const rankScore = new Map(candidates.map((candidate, index) => [candidate.id, 1 - index / Math.max(1, candidates.length - 1)]));
  const remaining = [...candidates];
  const chosen: LineupCandidate[] = [];
  while (chosen.length < count && remaining.length) {
    let bestIndex = 0;
    let bestScore = -Infinity;
    let bestSimilarity = 0;
    for (let i = 0; i < remaining.length; i += 1) {
      const candidate = remaining[i];
      if (!canAddToPortfolio(chosen, candidate, constraints, count)) continue;
      const similarity = chosen.length ? Math.max(...chosen.map((existing) => overlap(existing.playerIds, candidate.playerIds))) : 0;
      const score = (rankScore.get(candidate.id) ?? 0) - DIVERSITY_WEIGHT * similarity;
      if (score > bestScore) { bestScore = score; bestIndex = i; bestSimilarity = similarity; }
    }
    if (bestScore === -Infinity) break;
    const [picked] = remaining.splice(bestIndex, 1);
    chosen.push({ ...picked, strategicSimilarity: bestSimilarity });
  }
  return { selected: chosen, underfilled: chosen.length < count };
}

function choosePortfolio(candidates: LineupCandidate[], count: number, isCashGame: boolean, constraints?: PortfolioConstraints): { selected: LineupCandidate[]; underfilled: boolean } {
  if (isCashGame || count <= 1) return choosePortfolioForCashGame(candidates, count, constraints);
  return choosePortfolioDiverse(candidates, count, constraints);
}

function watchItemsFor(research: ResearchPackage, playerIds: string[]): string[] {
  return (research.watchItems ?? [])
    .filter((item) => item.importance === 'CRITICAL' && (!item.subjectId || playerIds.includes(item.subjectId)))
    .map((item) => item.reason);
}

function explain(candidate: LineupCandidate, bulletNumber: number, input: SelectionInput, isCashGame: boolean): SelectedLineup {
  const news = input.researchPackage.findings.filter((finding) => candidate.playerIds.includes(finding.subjectId) && finding.bucket === 'NEWS_EXTERNAL_CONTEXT').slice(0, 2).map((finding) => `${finding.sourceName}: ${finding.finding}`);
  const cashLine = resolveCashLineProbability(candidate, input.cashLineCalibration);
  const rationale = [
    `Median ${format(candidate.median)} with a ${format(candidate.ceiling)} ceiling.`,
    candidate.candidateTypes.length ? `Profile: ${candidate.candidateTypes.join(', ').replaceAll('_', ' ').toLowerCase()}.` : "Selected from the optimizer's ranked candidate set.",
    candidate.riskFlags.length ? `Watch: ${candidate.riskFlags[0]}` : 'No projection risk flag was attached to this candidate.',
  ];
  if (input.validatedSlate.contest.objective !== 'MAX_FPTS' && candidate.contestMetricProvenance !== 'JOINT_FIELD_SIMULATION') rationale.push('Contest rank is not modeled: this order uses a lineup construction heuristic, not a validated cash, win, or payout probability.');
  // Cash-game shortfall is disclosed, never hidden -- the portfolio is still filled from the best
  // available candidate (choosePortfolio never blocks), this only makes clear when that candidate
  // didn't actually clear the 85% target rather than silently presenting it as if it had.
  if (isCashGame && cashLine.probability !== undefined && cashLine.probability < CASH_LINE_TARGET_PROBABILITY) rationale.push(`Best available cash-line confidence is ${Math.round(cashLine.probability * 100)}% (${cashLine.confidence === 'CALIBRATED' ? 'calibrated' : 'simulated estimate'}), below the ${Math.round(CASH_LINE_TARGET_PROBABILITY * 100)}% target — no candidate in this pool cleared it.`);
  if (candidate.candidateTypes.includes('LEVERAGE') || candidate.candidateTypes.includes('LOW_DUPLICATION')) rationale.push('Leverage and duplication figures are construction heuristics, not real field-ownership data.');
  if (candidate.strategicSimilarity >= 0.8) rationale.push('This lineup closely overlaps with another selected lineup due to a limited pool of distinct high-quality builds.');
  const watchItems = watchItemsFor(input.researchPackage, candidate.playerIds);
  return { candidateId: candidate.id, bulletNumber, selectionType: candidate.candidateTypes[0] ?? 'OPTIMIZER_RANKED', explanation: buildExplanation(candidate, input.validatedSlate), newsContext: news, rationale, playerIds: candidate.playerIds, rosterSlots: candidate.rosterSlots, salaryUsed: candidate.salaryUsed, salaryRemaining: candidate.salaryRemaining, floor: candidate.floor, expectedPoints: candidate.expectedPoints, median: candidate.median, ceiling: candidate.ceiling, watchItems, readinessStatus: 'PROVISIONAL', cashLineProbability: cashLine.probability, cashLineConfidence: cashLine.confidence };
}

function buildExplanation(candidate: LineupCandidate, slate: ValidatedSlate): string {
  const topPlayers = candidate.playerIds
    .map((id) => slate.playerPool.find((player) => player.playerId === id))
    .filter((player): player is SlatePlayer => Boolean(player))
    .sort((a, b) => b.salary - a.salary)
    .slice(0, 2)
    .map((player) => player.playerName);
  const typeLabel = candidate.candidateTypes.length ? candidate.candidateTypes.join(', ').replaceAll('_', ' ').toLowerCase() : "the optimizer's top-ranked build";
  const correlationNote = candidate.correlationScore > 0.05 ? ' with meaningful same-team correlation' : '';
  const anchor = topPlayers.length ? ` anchored by ${topPlayers.join(' and ')}` : '';
  const forecast = candidate.expectedPoints === undefined ? `median ${format(candidate.median)}` : `mean ${format(candidate.expectedPoints)} / median ${format(candidate.median)}`;
  return `Selected as ${typeLabel}${anchor}${correlationNote}, with modeled ${forecast} points on $${(candidate.salaryUsed / 1000).toFixed(1)}k of the $${(slate.salaryCap / 1000).toFixed(1)}k cap.`;
}

export function overlap(a: string[], b: string[]): number { const set = new Set(a); return b.filter((id) => set.has(id)).length / Math.max(a.length, b.length, 1); }
function format(value: number): string { return Number.isFinite(value) ? value.toFixed(1) : '—'; }
function heuristicTournamentRankOf(candidate: LineupCandidate): number { return candidate.heuristicTournamentRank ?? candidate.tournamentRank ?? Number.MAX_SAFE_INTEGER; }

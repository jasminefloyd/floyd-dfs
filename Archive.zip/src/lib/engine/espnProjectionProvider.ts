import type { ValidatedSlate } from './contracts.js';
import { normalizeTeamCode, type AvailabilityRecord, type AvailabilitySnapshot } from './availability.js';
import { fetchEspnJson } from './espnApiClient.js';
import { DK_SCORING } from '../dkScoring.js';

export interface BasketballProjectionRecord { name: string; team: string; opponent?: string; gameId?: string; providerFppg: number; source: string; }

const ESPN_AVAILABILITY_SPORT_PATH: Partial<Record<ValidatedSlate['sport'], { sportGroup: string; league: string }>> = {
  NBA: { sportGroup: 'basketball', league: 'nba' },
  WNBA: { sportGroup: 'basketball', league: 'wnba' },
  NFL: { sportGroup: 'football', league: 'nfl' },
  CFB: { sportGroup: 'football', league: 'college-football' },
};

export class EspnProjectionClient {
  private readonly fetcher: typeof fetch;
  private readonly baseUrl: string;
  private readonly commonBaseUrl: string;
  constructor(baseUrl: string, fetcher?: typeof fetch) {
    this.baseUrl = baseUrl.replace(/\/+$/, '');
    this.commonBaseUrl = 'https://site.web.api.espn.com/apis/common/v3';
    this.fetcher = fetcher ?? fetch;
  }

  async getBasketballProjectionSnapshot(slate: ValidatedSlate, signal?: AbortSignal): Promise<BasketballProjectionRecord[]> {
    if (slate.sport !== 'NBA' && slate.sport !== 'WNBA') return [];
    const league = slate.sport.toLowerCase() as 'nba' | 'wnba';
    const date = espnDate(slate);
    const scoreboard = await this.getJson(`${this.baseUrl}/sports/basketball/${league}/scoreboard?dates=${date}`, signal);
    const teams = new Set(slate.playerPool.map((player) => normalizeTeamCode(String(player.team ?? ''))).filter(Boolean));
    const expectedPairs = new Set((slate.games ?? []).map((game) => game.teamIds.map(normalizeTeamCode).filter(Boolean).sort().join(':')).filter((pair) => pair.includes(':')));
    const events = listRecords(scoreboard.events).filter((candidate) => {
      const competitors = listRecords(listRecords(candidate.competitions)[0]?.competitors);
      const eventTeams = new Set(competitors.map((competitor) => teamCode(competitor.team)).filter(Boolean));
      const pair = [...eventTeams].sort().join(':');
      return eventTeams.size === 2 && [...eventTeams].every((team) => teams.has(team)) && (!expectedPairs.size || expectedPairs.has(pair));
    });
    if (!events.length) return [];
    const seen = new Set<string>();
    const rosterRows = await Promise.all(events.flatMap((event) => {
      const eventId = text(event.id);
      const competitors = listRecords(listRecords(event.competitions)[0]?.competitors);
      return competitors.filter((competitor) => teams.has(teamCode(competitor.team))).map(async (competitor) => {
      const team = teamCode(competitor.team);
      const opponent = competitors.filter((other) => other !== competitor).map((other) => teamCode(other.team)).find(Boolean);
      const teamId = text(asRecord(competitor.team)?.id);
      if (!teamId) return [];
      const roster = await this.getJson(`${this.baseUrl}/sports/basketball/${league}/teams/${teamId}/roster`, signal);
      const athletes = listRecords(roster.athletes);
      const projections = await Promise.all(athletes.map(async (athlete) => {
        const athleteId = text(athlete.id);
        if (!athleteId) return undefined;
        try {
          const profile = await this.getJson(`${this.commonBaseUrl}/sports/basketball/${league}/athletes/${athleteId}`, signal);
          const statsSummary = asRecord(asRecord(profile.athlete)?.statsSummary);
          const stats = listRecords(statsSummary?.statistics);
          const values = new Map(stats.map((stat) => [text(stat.name), number(stat.value)]));
          const points = values.get('avgPoints'); const rebounds = values.get('avgRebounds'); const assists = values.get('avgAssists'); const steals = values.get('avgSteals');
          const threes = values.get('avgThreePointFieldGoalsMade') ?? values.get('avgThreePointersMade');
          const blocks = values.get('avgBlocks'); const turnovers = values.get('avgTurnovers');
          if (![points, rebounds, assists, steals, threes, blocks, turnovers].every((value) => Number.isFinite(value))) return undefined;
          const name = text(athlete.fullName ?? athlete.displayName);
          if (!name) return undefined;
          // Season means are not actual box scores: score their linear categories only and
          // never award DD/TD bonuses based on rounded averages.
          const providerFppg = points! * DK_SCORING[league].points + threes! * DK_SCORING[league].threePointersMade
            + rebounds! * DK_SCORING[league].rebounds + assists! * DK_SCORING[league].assists
            + steals! * DK_SCORING[league].steals + blocks! * DK_SCORING[league].blocks
            + turnovers! * DK_SCORING[league].turnovers;
          const identity = `${eventId}:${athleteId}`;
          if (seen.has(identity)) return undefined;
          seen.add(identity);
          return { name, team, opponent, gameId: eventId || undefined, providerFppg, source: 'ESPN season averages (linear categories; bonuses excluded)' };
        } catch {
          return undefined;
        }
      }));
      return projections.filter((value) => Boolean(value)) as BasketballProjectionRecord[];
      });
    }));
    return rosterRows.flat().filter((value) => value !== undefined) as BasketballProjectionRecord[];
  }

  // NBA/WNBA/NFL/CFB availability, sourced from ESPN's team roster endpoint (already reachable via
  // this.baseUrl; no dedicated confirmed-lineup feed like MLB's SportsDataIO integration exists
  // for these sports). Each athlete carries a `status` object and an `injuries` array; the exact
  // non-"active" status.type/injury-status taxonomy wasn't verified against a real
  // injured/questionable player during implementation, so unrecognized values fall back to
  // UNKNOWN (never guessed as OUT) rather than risk excluding a healthy player. For NFL/CFB,
  // roster membership is deliberately not treated as a confirmed starting role.
  async getAvailabilitySnapshot(slate: ValidatedSlate, signal?: AbortSignal): Promise<AvailabilitySnapshot> {
    const sportPath = ESPN_AVAILABILITY_SPORT_PATH[slate.sport];
    if (!sportPath) return { source: 'ESPN', retrievedAt: new Date().toISOString(), records: [], confirmedLineupAvailable: false, note: `${slate.sport} has no configured ESPN availability mapping.` };
    const teams = [...new Set(slate.playerPool.map((player) => normalizeTeamCode(player.team)).filter(Boolean))];
    // ESPN roster endpoints are keyed by numeric team IDs. Resolve event IDs for
    // basketball too; team abbreviations such as DK's LVA do not reliably work as
    // ESPN roster path segments (which can return an empty roster or 404).
    const teamIds = await this.resolveEventTeamIds(slate, teams, sportPath, signal);
    const diagnostics: NonNullable<AvailabilitySnapshot['diagnostics']> = [];
    const rosterRows = await Promise.all(teams.map(async (team) => {
      try {
        const teamResource = teamIds.get(team) ?? team.toLowerCase();
        const roster = await this.getJson(`${this.baseUrl}/sports/${sportPath.sportGroup}/${sportPath.league}/teams/${teamResource}/roster`, signal);
        const groups = listRecords(roster.athletes);
        const athletes = groups.length && groups[0].items !== undefined ? groups.flatMap((group) => listRecords(group.items)) : groups;
        return athletes.flatMap((athlete): AvailabilityRecord[] => {
          const name = text(athlete.fullName ?? athlete.displayName);
          if (!name) return [];
          const status = espnAvailabilityStatus(athlete);
          const headshot = asRecord(athlete.headshot);
          const photoUrl = text(headshot?.href ?? athlete.headshot).trim();
          return [{ playerName: name, team, providerPlayerId: text(athlete.id) || undefined, photoUrl: photoUrl || undefined, status, roleStatus: ['NFL', 'CFB'].includes(slate.sport) ? 'ROLE_UNCONFIRMED' : undefined, confirmed: false, updatedAt: new Date().toISOString(), note: ['NFL', 'CFB'].includes(slate.sport) ? 'Listed on ESPN roster; starting role was not confirmed by this source.' : undefined }];
        });
      } catch (error) { diagnostics.push({ provider: `ESPN ${slate.sport} roster ${team}`, status: 'FAILED', error: error instanceof Error ? error.message : `ESPN roster request failed for ${team}.`, retrievedAt: new Date().toISOString() }); return []; }
    }));
    const records = rosterRows.flat();
    const minimumRosterSize = slate.sport === 'WNBA' ? 8 : slate.sport === 'NBA' ? 10 : 1;
    const rosterComplete = teams.length > 0 && teams.every((team) => records.filter((record) => normalizeTeamCode(record.team) === team).length >= minimumRosterSize);
    return { source: 'ESPN', retrievedAt: new Date().toISOString(), records, confirmedLineupAvailable: false, rosterComplete, diagnostics, note: records.length ? undefined : 'ESPN roster data was unavailable for this slate.' };
  }

  private async resolveEventTeamIds(slate: ValidatedSlate, teams: string[], sportPath: { sportGroup: string; league: string }, signal?: AbortSignal): Promise<Map<string, string>> {
    try {
      const date = espnDate(slate);
      const scoreboard = await this.getJson(`${this.baseUrl}/sports/${sportPath.sportGroup}/${sportPath.league}/scoreboard?dates=${date}`, signal);
      const resolved = new Map<string, string>();
      for (const event of listRecords(scoreboard.events)) {
        for (const competition of listRecords(event.competitions)) {
          for (const competitor of listRecords(competition.competitors)) {
            const team = asRecord(competitor.team);
            const code = normalizeTeamCode(text(team?.abbreviation));
            const id = text(team?.id);
            if (code && id && teams.includes(code)) resolved.set(code, id);
          }
        }
      }
      return resolved;
    } catch {
      return new Map();
    }
  }

  private async getJson(url: string, signal?: AbortSignal): Promise<Record<string, unknown>> {
    const { payload } = await fetchEspnJson(url, { signal, fetcher: this.fetcher });
    return payload;
  }
}

function espnDate(slate: ValidatedSlate): string { const date = new Date(slate.event.eventDate); if (date.getUTCHours() < 6) date.setUTCDate(date.getUTCDate() - 1); return date.toISOString().slice(0, 10).replaceAll('-', ''); }
function listRecords(value: unknown): Record<string, unknown>[] { return Array.isArray(value) ? value.flatMap((item) => asRecord(item) ? [asRecord(item)!] : []) : []; }
function asRecord(value: unknown): Record<string, unknown> | undefined { return value && typeof value === 'object' && !Array.isArray(value) ? value as Record<string, unknown> : undefined; }
function text(value: unknown): string { return typeof value === 'string' || typeof value === 'number' ? String(value) : ''; }
function number(value: unknown): number { return typeof value === 'number' ? value : Number(value); }
function teamCode(value: unknown): string { return normalizeTeamCode(text(asRecord(value)?.abbreviation ?? asRecord(value)?.shortDisplayName)); }
function espnAvailabilityStatus(athlete: Record<string, unknown>): AvailabilityRecord['status'] {
  const injuries = listRecords(athlete.injuries);
  const injuryText = injuries.map((injury) => text(injury.status ?? asRecord(injury.details)?.type)).join(' ').toLowerCase();
  if (/out|inactive|suspend|injured.reserve|\bil\b/.test(injuryText)) return 'OUT';
  if (/day.to.day|questionable|probable|game.time/.test(injuryText)) return 'PROJECTED';
  const statusType = text(asRecord(athlete.status)?.type).toLowerCase();
  if (statusType === 'active') return injuries.length ? 'PROJECTED' : 'ACTIVE';
  if (/out|inactive|suspend/.test(statusType)) return 'OUT';
  return 'UNKNOWN';
}

import type { SlatePlayer, Sport } from './contracts.js';
import { normalizeProviderName, normalizeTeamCode } from './availability.js';

// Converts raw SportsDataIO PlayerGameProjectionStatsByDate rows into the per-minute/PA/
// inning/target rate fields projection.ts's REQUIRED lists expect. Field names are read
// defensively (multiple plausible key variants) because this repo has no live SportsDataIO
// subscription to verify exact field names against; a player who doesn't match or lacks the
// needed fields simply gets no projectionInputs and falls back to the providerFppg path in
// projection.ts — never a guessed rate.
// SportsDataIO's PlayerSeasonStats rows carry season TOTALS (e.g. PlateAppearances across the
// whole season), not a single game's line -- every *PerPA/*PerMinute/*PerInning rate below is
// already correct computed straight against those totals (a rate is scale-invariant between a
// season and a single game), but the "expected volume" field (expectedPA, expectedMinutes,
// expectedInnings, passAttempts/targets/carries) must become a per-game average, not the raw
// season sum. `gamesPlayed` does exactly that division; callers passing single-game rows keep
// today's behavior unchanged via the default of 1.
export function deriveSeasonBasedInputs(sport: Sport, player: SlatePlayer, seasonRows: Record<string, unknown>[], options: { allowTeamMismatch?: boolean } = {}): Record<string, number> | undefined {
  const row = findRow(player, seasonRows, options.allowTeamMismatch === true);
  if (!row) return undefined;
  const gamesPlayed = gamesPlayedFromRow(row);
  if (gamesPlayed <= 0) return undefined;
  if (sport === 'NBA' || sport === 'WNBA') return deriveBasketballInputs(row, gamesPlayed);
  if (sport === 'MLB') return isPitcher(player) ? derivePitcherInputs(row, player, gamesPlayed) : deriveHitterInputs(row, gamesPlayed);
  if (sport === 'NFL' || sport === 'CFB') return isQuarterback(player) ? deriveQuarterbackInputs(row, gamesPlayed) : deriveSkillPlayerInputs(row, gamesPlayed);
  return undefined;
}

/**
 * Blends current- and prior-season rates when both are actually available. The weights are
 * explicit model inputs, not claims of statistical calibration; callers record the resulting
 * provenance in the stage warnings. Missing sides are never replaced with fabricated zeros.
 */
export function deriveWeightedSeasonInputs(sport: Sport, player: SlatePlayer, currentRows: Record<string, unknown>[], priorRows: Record<string, unknown>[], currentWeight: number, options: { allowTeamMismatch?: boolean } = {}): { inputs?: Record<string, number>; usedPrior: boolean } {
  const current = deriveSeasonBasedInputs(sport, player, currentRows, options);
  const prior = deriveSeasonBasedInputs(sport, player, priorRows, options);
  if (!current && !prior) return { usedPrior: false };
  if (!current) return { inputs: prior, usedPrior: true };
  if (!prior) return { inputs: current, usedPrior: false };
  const weight = Math.max(0, Math.min(1, currentWeight));
  const keys = new Set([...Object.keys(current), ...Object.keys(prior)]);
  const inputs = Object.fromEntries([...keys].flatMap((key) => {
    const currentValue = current[key];
    const priorValue = prior[key];
    if (Number.isFinite(currentValue) && Number.isFinite(priorValue)) return [[key, currentValue * weight + priorValue * (1 - weight)]];
    if (Number.isFinite(currentValue)) return [[key, currentValue]];
    if (Number.isFinite(priorValue)) return [[key, priorValue]];
    return [];
  }));
  return { inputs, usedPrior: true };
}

export function isPitcher(player: { position?: string }): boolean { return /^(SP|RP|P)$/i.test(player.position ?? ''); }
export function isQuarterback(player: { position?: string }): boolean { return /^QB$/i.test(player.position ?? ''); }

// MLB/NBA report games played under `Games`; NFL's season-stats endpoint uses `Played` instead
// (verified live -- `Games` comes back undefined for every NFL row on this account).
export function gamesPlayedFromRow(row: Record<string, unknown>): number { return readNumber(row, ['Games', 'Played', 'games']) ?? 0; }

/** Resolve DraftKings IDs through SportsDataIO's current NBA roster, requiring a
 * unique provider ID and an exact normalized current-team match. */
export function mapSportsDataIoRosterIdentities<T extends SlatePlayer>(players: T[], rosterRows: Record<string, unknown>[]): { players: T[]; mapped: number; unresolved: number; conflicts: number } {
  let mapped = 0;
  let unresolved = 0;
  let conflicts = 0;
  const result = players.map((player) => {
    const draftKingsId = String(player.identity?.draftKingsId ?? player.playerId).trim();
    const matches = rosterRows.filter((row) => String(row.DraftKingsPlayerID ?? row.DraftKingsPlayerId ?? '').trim() === draftKingsId);
    const providerIds = [...new Set(matches.map((row) => readString(row, ['PlayerID', 'PlayerId', 'playerId'])).filter((id): id is string => Boolean(id)))];
    if (providerIds.length !== 1) { unresolved += 1; return player; }
    const providerId = providerIds[0];
    const providerTeams = [...new Set(matches.filter((row) => readString(row, ['PlayerID', 'PlayerId', 'playerId']) === providerId).map((row) => normalizeTeamCode(readString(row, ['Team', 'team', 'TeamAbbreviation']) ?? '')).filter(Boolean))];
    const slateTeam = normalizeTeamCode(player.team ?? '');
    if (providerTeams.length !== 1 || !slateTeam || providerTeams[0] !== slateTeam) { unresolved += 1; return player; }
    if (player.identity?.sportsDataIoId && player.identity.sportsDataIoId !== providerId) { conflicts += 1; return player; }
    if (player.identity?.sportsDataIoId === providerId) return player;
    mapped += 1;
    return { ...player, identity: { ...player.identity, sportsDataIoId: providerId, confidence: 'EXACT' as const, matchedBy: 'PROVIDER_ID' as const } };
  });
  return { players: result, mapped, unresolved, conflicts };
}

/** Provisional NBA shrinkage schedule: current-season rates gain weight with sample size. */
export function currentSeasonWeight(sport: Sport, currentGames: number): number {
  if (sport === 'NBA') return Math.max(0.2, Math.min(0.85, currentGames / (currentGames + 20)));
  if (sport === 'NFL' || sport === 'CFB') return currentGames >= 4 ? 0.7 : 0.5;
  return 0.7;
}

export function findRow(player: SlatePlayer, rows: Record<string, unknown>[], allowTeamMismatch = false): Record<string, unknown> | undefined {
  const providerId = player.identity?.sportsDataIoId;
  if (providerId) {
    const idMatch = rows.find((row) => readString(row, ['PlayerID', 'PlayerId', 'playerId', 'PlayerKey', 'playerKey']) === providerId);
    if (idMatch) return idMatch;
    return undefined;
  }
  const targetName = normalizeProviderName(player.playerName);
  const targetTeam = normalizeTeamCode(player.team);
  const matches = rows.filter((row) => {
    const name = normalizeProviderName(readString(row, ['Name', 'PlayerName', 'name']) ?? providerFullName(row));
    const team = normalizeTeamCode(readString(row, ['Team', 'team', 'TeamAbbreviation']));
    return name === targetName && (allowTeamMismatch || !targetTeam || !team || team === targetTeam);
  });
  if (!matches.length) return undefined;
  // Prefer an exact team match. A name-only match is safe only when the provider
  // returned one unambiguous row; silently choosing between same-name players can
  // attach another team's rates to this slate.
  const exactTeam = targetTeam ? matches.filter((row) => normalizeTeamCode(readString(row, ['Team', 'team', 'TeamAbbreviation'])) === targetTeam) : [];
  if (exactTeam.length === 1) return exactTeam[0];
  return matches.length === 1 ? matches[0] : undefined;
}

function deriveBasketballInputs(row: Record<string, unknown>, gamesPlayed = 1): Record<string, number> | undefined {
  const minutes = readNumber(row, ['Minutes', 'minutes']);
  if (!minutes || minutes <= 0 || gamesPlayed <= 0) return undefined;
  const points = readNumber(row, ['Points', 'points']) ?? 0;
  const rebounds = readNumber(row, ['Rebounds', 'rebounds']) ?? 0;
  const assists = readNumber(row, ['Assists', 'assists']) ?? 0;
  const steals = readNumber(row, ['Steals', 'steals']) ?? 0;
  const blocks = readNumber(row, ['BlockedShots', 'Blocks', 'blocks']) ?? 0;
  const turnovers = readNumber(row, ['Turnovers', 'turnovers']) ?? 0;
  const threes = readNumber(row, ['ThreePointersMade', 'threePointersMade']) ?? 0;
  return { expectedMinutes: minutes / gamesPlayed, pointsPerMinute: points / minutes, reboundsPerMinute: rebounds / minutes, assistsPerMinute: assists / minutes, stealsPerMinute: steals / minutes, blocksPerMinute: blocks / minutes, turnoversPerMinute: turnovers / minutes, threesPerMinute: threes / minutes };
}

function deriveHitterInputs(row: Record<string, unknown>, gamesPlayed = 1): Record<string, number> | undefined {
  const atBats = readNumber(row, ['AtBats', 'atBats']) ?? 0;
  const walks = readNumber(row, ['Walks', 'BaseOnBalls', 'walks']) ?? 0;
  const hitByPitch = readNumber(row, ['HitByPitch', 'hitByPitch']) ?? 0;
  const sacFly = readNumber(row, ['SacrificeFlies', 'sacrificeFlies']) ?? 0;
  const plateAppearances = readNumber(row, ['PlateAppearances', 'plateAppearances']) ?? (atBats + walks + hitByPitch + sacFly);
  if (!plateAppearances || plateAppearances <= 0 || gamesPlayed <= 0) return undefined;
  const hits = readNumber(row, ['Hits', 'hits']) ?? 0;
  const doubles = readNumber(row, ['Doubles', 'doubles']) ?? 0;
  const triples = readNumber(row, ['Triples', 'triples']) ?? 0;
  const homeRuns = readNumber(row, ['HomeRuns', 'homeRuns']) ?? 0;
  // Some season-stat endpoints omit singles while returning hits and extra-base hits.
  // Derive the residual instead of silently projecting every hit as a non-single.
  const singles = readNumber(row, ['Singles', 'singles']) ?? Math.max(0, hits - doubles - triples - homeRuns);
  const totalBases = readNumber(row, ['TotalBases', 'totalBases']) ?? (singles || (hits - doubles - triples - homeRuns)) + doubles * 2 + triples * 3 + homeRuns * 4;
  const rbi = readNumber(row, ['RunsBattedIn', 'RBI', 'rbi']) ?? 0;
  const runs = readNumber(row, ['Runs', 'runs']) ?? 0;
  const stolenBases = readNumber(row, ['StolenBases', 'stolenBases']) ?? 0;
  return { expectedPA: plateAppearances / gamesPlayed, hitRate: hits / plateAppearances, singlesPerPA: singles / plateAppearances, doublesPerPA: doubles / plateAppearances, triplesPerPA: triples / plateAppearances, homeRunsPerPA: homeRuns / plateAppearances, walksPerPA: walks / plateAppearances, hitByPitchPerPA: hitByPitch / plateAppearances, totalBasesPerPA: totalBases / plateAppearances, rbiPerPA: rbi / plateAppearances, runsPerPA: runs / plateAppearances, stolenBasesPerPA: stolenBases / plateAppearances };
}

// PlayerSeasonStats rows carry a batter/pitcher split -- a pitcher's own real strikeouts/walks/
// hits-allowed/earned-runs live under the Pitching*-prefixed fields (verified live: a real
// starting pitcher's season row had `Strikeouts: 0` (their own at-bats as a batter) but
// `PitchingStrikeouts: 62.8` (their real total)). Pitching* is checked first since it's the
// verified-correct field for season rows; the bare names stay as a fallback for any other row
// shape this function might still receive.
function derivePitcherInputs(row: Record<string, unknown>, player: SlatePlayer, gamesPlayed = 1): Record<string, number> | undefined {
  const innings = readNumber(row, ['InningsPitchedDecimal', 'InningsPitched', 'inningsPitched']);
  if (!innings || innings <= 0 || gamesPlayed <= 0) return undefined;
  const strikeouts = readNumber(row, ['PitchingStrikeouts', 'Strikeouts', 'strikeouts']) ?? 0;
  const walks = readNumber(row, ['PitchingWalks', 'Walks', 'BaseOnBallsAllowed', 'walks']) ?? 0;
  const hitsAllowed = readNumber(row, ['PitchingHits', 'HitsAllowed', 'hitsAllowed']) ?? 0;
  const earnedRuns = readNumber(row, ['PitchingEarnedRuns', 'EarnedRuns', 'earnedRuns']) ?? 0;
  const wins = readNumber(row, ['PitchingWins', 'Wins', 'wins']);
  const starts = readNumber(row, ['PitchingGamesStarted', 'GamesStarted', 'gamesStarted']);
  const startingRole = /^SP$/i.test(player.position ?? '') || player.availability?.status === 'CONFIRMED_STARTER' || player.availability?.roleStatus === 'CONFIRMED_STARTER';
  // Total season innings must be divided by starts for a starting pitcher, not all games
  // appeared. Relievers use appearances because their workload is per bullpen appearance.
  // If starter role is known but starts are absent, leave the workload unresolved.
  if (startingRole && (!starts || starts <= 0)) return undefined;
  const expectedInnings = innings / (startingRole ? starts! : gamesPlayed);
  const result = { expectedInnings, strikeoutsPerInning: strikeouts / innings, walksPerInning: walks / innings, hitsAllowedPerInning: hitsAllowed / innings, earnedRunsPerInning: earnedRuns / innings };
  return wins !== undefined && starts !== undefined && starts > 0 ? { ...result, winProbability: Math.max(0, Math.min(1, wins / starts)) } : result;
}

function deriveQuarterbackInputs(row: Record<string, unknown>, gamesPlayed = 1): Record<string, number> | undefined {
  const attempts = readNumber(row, ['PassingAttempts', 'passingAttempts']);
  if (!attempts || attempts <= 0 || gamesPlayed <= 0) return undefined;
  const completions = readNumber(row, ['PassingCompletions', 'Completions', 'passingCompletions']) ?? 0;
  const passingYards = readNumber(row, ['PassingYards', 'passingYards']) ?? 0;
  const passingTouchdowns = readNumber(row, ['PassingTouchdowns', 'passingTouchdowns']) ?? 0;
  const interceptions = readNumber(row, ['PassingInterceptions', 'Interceptions', 'passingInterceptions']) ?? 0;
  const carries = readNumber(row, ['RushingAttempts', 'rushingAttempts']) ?? 0;
  const rushingYards = readNumber(row, ['RushingYards', 'rushingYards']) ?? 0;
  const rushingTouchdowns = readNumber(row, ['RushingTouchdowns', 'rushingTouchdowns']) ?? 0;
  return { passAttempts: attempts / gamesPlayed, completionRate: completions / attempts, yardsPerCompletion: completions > 0 ? passingYards / completions : 0, passingTouchdownRate: passingTouchdowns / attempts, interceptionRate: interceptions / attempts, carries: carries / gamesPlayed, yardsPerCarry: carries > 0 ? rushingYards / carries : 0, touchdownProbability: rushingTouchdowns / gamesPlayed };
}

function deriveSkillPlayerInputs(row: Record<string, unknown>, gamesPlayed = 1): Record<string, number> | undefined {
  const targets = readNumber(row, ['ReceivingTargets', 'Targets', 'targets']) ?? 0;
  const carries = readNumber(row, ['RushingAttempts', 'rushingAttempts']) ?? 0;
  if ((targets <= 0 && carries <= 0) || gamesPlayed <= 0) return undefined;
  const snaps = readNumber(row, ['OffensiveSnapsPlayed', 'Snaps', 'snaps']) ?? 0;
  const routes = readNumber(row, ['RoutesRun', 'routes']) ?? targets;
  const receptions = readNumber(row, ['Receptions', 'receptions']) ?? 0;
  const receivingYards = readNumber(row, ['ReceivingYards', 'receivingYards']) ?? 0;
  const receivingTouchdowns = readNumber(row, ['ReceivingTouchdowns', 'receivingTouchdowns']) ?? 0;
  const rushingYards = readNumber(row, ['RushingYards', 'rushingYards']) ?? 0;
  const rushingTouchdowns = readNumber(row, ['RushingTouchdowns', 'rushingTouchdowns']) ?? 0;
  return { snaps: snaps / gamesPlayed, routes: routes / gamesPlayed, targets: targets / gamesPlayed, carries: carries / gamesPlayed, catchRate: targets > 0 ? receptions / targets : 0, yardsPerTarget: targets > 0 ? receivingYards / targets : 0, yardsPerCarry: carries > 0 ? rushingYards / carries : 0, touchdownProbability: (receivingTouchdowns + rushingTouchdowns) / gamesPlayed };
}

function readString(record: Record<string, unknown>, keys: string[]): string | undefined { for (const key of keys) if ((typeof record[key] === 'string' || typeof record[key] === 'number') && String(record[key]).trim()) return String(record[key]).trim(); return undefined; }
function providerFullName(record: Record<string, unknown>): string { const first = readString(record, ['FirstName', 'firstName']); const last = readString(record, ['LastName', 'lastName']); return first && last ? `${first} ${last}` : first ?? last ?? ''; }
function readNumber(record: Record<string, unknown>, keys: string[]): number | undefined { for (const key of keys) { const value = record[key]; if (typeof value === 'number' && Number.isFinite(value)) return value; if (typeof value === 'string' && value.trim() && Number.isFinite(Number(value))) return Number(value); } return undefined; }

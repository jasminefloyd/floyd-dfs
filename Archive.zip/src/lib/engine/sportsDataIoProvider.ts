import type { ResearchArticle, ResearchPlan, ResearchSourceProvider, SourceTier, Sport, ValidatedSlate } from './contracts.js';
import { normalizeProviderName, normalizeTeamCode, parseAvailabilityRecords, type AvailabilityRecord, type AvailabilitySnapshot } from './availability.js';

export interface SportsDataIoQuotaState { limit?: number; remaining?: number; resetAt?: string; retryAfterAt?: string; rateLimited: boolean; observedAt: string; }
export interface SportsDataIoClientOptions { apiKey: string; baseUrl?: string; fetcher?: typeof fetch; availability?: Partial<Record<Sport, { feed: string; resource: string }>>; timeoutMs?: number; maxAttempts?: number; requestBudget?: number; onQuotaState?: (state: SportsDataIoQuotaState) => void; }
export interface GolfProjectionRefresh { rows: Record<string, unknown>[]; tournamentName?: string; warning?: string; }
export interface SportsDataIoGameWeather { gameId?: string; homeTeam?: string; awayTeam?: string; homeProbablePitcherId?: string; awayProbablePitcherId?: string; homeProbablePitcher?: string; awayProbablePitcher?: string; homeOpener?: boolean; awayOpener?: boolean; temperatureLow?: number; temperatureHigh?: number; windSpeed?: number; windDirection?: string; description?: string; }
export interface WnbaRecentPlayerMinutes { playerId?: string; name?: string; team?: string; minutes: number[]; }
export interface NbaRecentPlayerGame { playerId?: string; name?: string; team?: string; gameId?: string; date?: string; minutes: number; started?: boolean; }

export class SportsDataIoClient {
  private readonly fetcher: typeof fetch;
  private readonly baseUrl: string;
  private readonly options: SportsDataIoClientOptions;
  private readonly timeoutMs: number;
  private readonly maxAttempts: number;
  private quotaState: SportsDataIoQuotaState | undefined;
  private providerCallCount = 0;
  constructor(options: SportsDataIoClientOptions) { this.options = options; this.fetcher = options.fetcher ?? fetch; this.baseUrl = (options.baseUrl ?? 'https://api.sportsdata.io/v3').replace(/\/+$/, ''); this.timeoutMs = options.timeoutMs ?? 12_000; this.maxAttempts = options.maxAttempts ?? 3; if (!options.apiKey) throw new Error('SportsDataIO API key is required.'); }
  async get<T>(sport: Sport, feed: string, resource: string, parameter?: string, signal?: AbortSignal): Promise<T> {
    const path = this.sourceUrl(sport, feed, resource, parameter);
    return await this.fetchJson<T>(path, `SportsDataIO ${sport} ${feed}/${resource}`, signal);
  }
  get latestQuotaState(): SportsDataIoQuotaState | undefined { return this.quotaState ? { ...this.quotaState } : undefined; }
  get requestsMade(): number { return this.providerCallCount; }
  sourceUrl(sport: Sport, feed: string, resource: string, parameter?: string): string { return [this.baseUrl, sport.toLowerCase(), feed, 'json', resource, parameter].filter(Boolean).join('/'); }
  private async getGolf<T>(resource: string, parameter?: string, signal?: AbortSignal): Promise<T> {
    const golfBaseUrl = this.baseUrl.replace(/\/v3$/, '');
    const path = [golfBaseUrl, 'golf', 'v2', 'json', resource, parameter].filter(Boolean).join('/');
    return await this.fetchJson<T>(path, `SportsDataIO GOLF v2/${resource}`, signal);
  }
  private async fetchJson<T>(path: string, label: string, signal?: AbortSignal): Promise<T> {
    let lastError: unknown;
    for (let attempt = 1; attempt <= this.maxAttempts; attempt += 1) {
      if (this.options.requestBudget !== undefined && this.providerCallCount >= this.options.requestBudget) throw new Error('SportsDataIO request budget exhausted before the next provider call.');
      const controller = new AbortController();
      const abortFromCaller = () => controller.abort(signal?.reason);
      signal?.addEventListener('abort', abortFromCaller, { once: true });
      const timeout = setTimeout(() => controller.abort(new Error(`${label} request timed out.`)), this.timeoutMs);
      let response: Response | undefined;
      try { this.providerCallCount += 1; response = await this.fetcher(path, { signal: controller.signal, headers: { accept: 'application/json', 'Ocp-Apim-Subscription-Key': this.options.apiKey } }); }
      catch (error) { lastError = error; }
      finally { clearTimeout(timeout); signal?.removeEventListener('abort', abortFromCaller); }
      if (response) {
        this.recordQuotaHeaders(response.headers, response.status === 429);
        if (!response.ok) {
          const detail = await response.text().catch(() => '');
          if (response.status === 401 || response.status === 403) throw new Error(`${label} access denied (HTTP ${response.status}). Check subscription feed permissions.`);
          lastError = new Error(`${label} returned HTTP ${response.status}${detail ? `: ${detail.slice(0, 200)}` : ''}.`);
          if (response.status < 500 && response.status !== 408 && response.status !== 429) throw lastError;
          if (attempt < this.maxAttempts) {
            const retryAfter = response.headers.get('retry-after');
            const retryAfterSeconds = retryAfter && Number.isFinite(Number(retryAfter)) ? Number(retryAfter) * 1000 : undefined;
            const retryAfterDate = retryAfter && retryAfterSeconds === undefined ? Date.parse(retryAfter) - Date.now() : undefined;
            const serverRetryMs = retryAfterSeconds ?? (retryAfterDate !== undefined && Number.isFinite(retryAfterDate) ? Math.max(0, retryAfterDate) : undefined);
            if (response.status === 429 && serverRetryMs !== undefined && serverRetryMs > 5_000) throw lastError;
            const retryMs = serverRetryMs ?? 200 * (2 ** (attempt - 1)) + Math.floor(Math.random() * 150);
            await new Promise((resolve) => setTimeout(resolve, Math.min(5_000, retryMs)));
          }
          continue;
        }
        const contentType = response.headers.get('content-type') ?? '';
        if (!/^application\/(json|[a-z0-9.+-]+\+json)(\s*;|$)/i.test(contentType)) throw new Error(`${label} returned non-JSON content type: ${contentType || 'missing'}.`);
        try { return await response.json() as T; }
        catch (error) { throw new Error(`${label} returned malformed JSON: ${error instanceof Error ? error.message : 'parse failed'}.`); }
      }
      if (signal?.aborted) throw signal.reason instanceof Error ? signal.reason : new Error(`${label} request was aborted.`);
      if (attempt < this.maxAttempts) await new Promise((resolve) => setTimeout(resolve, Math.min(2_000, 200 * (2 ** (attempt - 1)) + Math.floor(Math.random() * 150))));
    }
    throw lastError instanceof Error ? lastError : new Error(`${label} request failed.`);
  }
  private recordQuotaHeaders(headers: Headers, rateLimited: boolean): void {
    const observedAt = new Date().toISOString();
    const numberHeader = (...names: string[]): number | undefined => {
      for (const name of names) { const value = headers.get(name); if (value !== null && /^\d+(?:\.\d+)?$/.test(value.trim())) return Number(value); }
      return undefined;
    };
    const dateHeader = (value: string | null): string | undefined => {
      if (!value) return undefined;
      const seconds = Number(value);
      const time = Number.isFinite(seconds) ? Date.now() + Math.max(0, seconds) * 1000 : Date.parse(value);
      return Number.isFinite(time) ? new Date(time).toISOString() : undefined;
    };
    const vendorReset = numberHeader('x-ratelimit-reset');
    const standardReset = numberHeader('ratelimit-reset');
    const vendorResetAt = vendorReset === undefined ? undefined : new Date(vendorReset > 1_000_000_000 ? vendorReset * 1000 : Date.now() + vendorReset * 1000).toISOString();
    const standardResetAt = standardReset === undefined ? undefined : new Date(Date.now() + standardReset * 1000).toISOString();
    const retryAfter = headers.get('retry-after');
    const retryAfterAt = dateHeader(retryAfter);
    const candidate: SportsDataIoQuotaState = {
      ...(numberHeader('x-ratelimit-limit', 'ratelimit-limit') !== undefined ? { limit: numberHeader('x-ratelimit-limit', 'ratelimit-limit') } : {}),
      ...(numberHeader('x-ratelimit-remaining', 'ratelimit-remaining') !== undefined ? { remaining: numberHeader('x-ratelimit-remaining', 'ratelimit-remaining') } : {}),
      ...(vendorResetAt ?? standardResetAt ?? dateHeader(headers.get('x-ratelimit-reset') ?? headers.get('ratelimit-reset')) ? { resetAt: vendorResetAt ?? standardResetAt ?? dateHeader(headers.get('x-ratelimit-reset') ?? headers.get('ratelimit-reset')) } : {}),
      ...(retryAfterAt ? { retryAfterAt } : {}), rateLimited, observedAt,
    };
    // Missing headers mean quota is unknown for this response; keep an unresolved 429 circuit
    // open until the provider supplies a reset signal and that time has passed.
    const priorBlocked = this.quotaState?.rateLimited === true;
    const priorReset = Math.max(Date.parse(this.quotaState?.resetAt ?? '') || 0, Date.parse(this.quotaState?.retryAfterAt ?? '') || 0);
    const suppliedQuota = candidate.remaining !== undefined || candidate.limit !== undefined || candidate.resetAt !== undefined;
    this.quotaState = !rateLimited && priorBlocked && !suppliedQuota && (!priorReset || priorReset > Date.now())
      ? { ...candidate, ...this.quotaState, observedAt }
      : candidate;
    this.options.onQuotaState?.({ ...this.quotaState });
  }
  async getAvailabilitySnapshot(slate: ValidatedSlate, signal?: AbortSignal): Promise<AvailabilitySnapshot> {
    const date = sportsDataDate(slate);
    if (slate.sport === 'MLB') {
      const retrievedAt = new Date().toISOString();
      const parsed = parseAvailabilityRecords(await this.get<unknown>('MLB', 'projections', 'StartingLineupsByDate', date, signal), slate.sport, retrievedAt);
      const slateTeams = new Set(slate.playerPool.map((player) => normalizeTeamCode(player.team)).filter(Boolean));
      const lineupRecords = parsed.records.filter((record) => slateTeams.has(normalizeTeamCode(record.team)));
      const rosterRecords = (await Promise.all([...slateTeams].map(async (team) => {
        const payload = await this.get<unknown>('MLB', 'scores', 'Players', team, signal);
        return (Array.isArray(payload) ? payload : []).flatMap((value): AvailabilityRecord[] => {
          const row = asRecord(value); if (!row) return [];
          const playerName = readString(row, ['Name', 'PlayerName', 'FullName', 'name', 'playerName']) ?? fullName(row); if (!playerName) return [];
          const providerTeam = readString(row, ['Team', 'team', 'TeamAbbreviation', 'Key']);
          if (providerTeam && normalizeTeamCode(providerTeam) !== normalizeTeamCode(team)) return [];
          const status = readString(row, ['Status', 'status']) ?? '';
          const unavailable = /inactive|injury|injured|restricted|bereavement|military|paternity/i.test(status);
          return [{ playerName, team, providerPlayerId: readIdentifier(row, ['PlayerID', 'PlayerId', 'playerId']), status: unavailable ? 'INACTIVE' : 'ACTIVE', roleStatus: 'UNKNOWN', confirmed: false, updatedAt: retrievedAt, note: 'SportsDataIO MLB player profile confirms team-roster membership; starting lineup is tracked separately.' }];
        });
      }))).flat();
      const byKey = new Map(rosterRecords.map((record) => [`${normalizeProviderName(record.playerName)}|${normalizeTeamCode(record.team)}`, record]));
      for (const record of lineupRecords) byKey.set(`${normalizeProviderName(record.playerName)}|${normalizeTeamCode(record.team)}`, record);
      const records = [...byKey.values()];
      const confirmedBattingOrdersByTeam = new Map<string, Set<number>>();
      for (const record of lineupRecords) {
        if (!record.confirmed || record.battingOrder === undefined || !record.team) continue;
        const team = normalizeTeamCode(record.team);
        const battingOrders = confirmedBattingOrdersByTeam.get(team) ?? new Set<number>();
        battingOrders.add(record.battingOrder);
        confirmedBattingOrdersByTeam.set(team, battingOrders);
      }
      // One confirmed row is not proof that MLB has locked the whole batting order. Treat the
      // feed as authoritative for this slate only after all nine batting spots are confirmed
      // for every team represented in the slate.
      const confirmedLineupAvailable = [...slateTeams].every((team) => (confirmedBattingOrdersByTeam.get(team)?.size ?? 0) >= 9);
      return { ...parsed, retrievedAt, records, confirmedLineupAvailable, note: `SportsDataIO MLB roster profiles and lineup records scoped to ${[...slateTeams].join('/')}.` };
    }
    if (slate.sport === 'CFB') return this.getCfbRosterSnapshot(slate, signal);
    if (slate.sport === 'NFL') return this.getNflAvailabilitySnapshot(slate, signal);
    const availability = this.options.availability?.[slate.sport];
    if (!availability) return { source: 'SPORTSDATAIO', retrievedAt: new Date().toISOString(), records: [], confirmedLineupAvailable: false, note: `${slate.sport} has no configured provider availability feed.` };
    return parseAvailabilityRecords(await this.get<unknown>(slate.sport, availability.feed, availability.resource, date, signal), slate.sport, new Date().toISOString());
  }
  private async getNflAvailabilitySnapshot(slate: ValidatedSlate, signal?: AbortSignal): Promise<AvailabilitySnapshot> {
    const retrievedAt = new Date().toISOString();
    const teams = new Set(slate.playerPool.map((player) => normalizeTeamCode(player.team)).filter(Boolean));
    const diagnostics: NonNullable<AvailabilitySnapshot['diagnostics']> = [];
    const load = async (feed: string, resource: string, parameter?: string, label = resource): Promise<unknown[]> => {
      try {
        const payload = await this.get<unknown>('NFL', feed, resource, parameter, signal);
        diagnostics.push({ provider: `SportsDataIO NFL ${feed}/${label}`, status: 'SUCCEEDED', retrievedAt });
        return rowsFromPayload(payload);
      } catch (error) {
        const message = error instanceof Error ? error.message : `SportsDataIO NFL ${feed}/${label} failed.`;
        const httpStatus = /HTTP (\d+)/.exec(message)?.[1];
        diagnostics.push({ provider: `SportsDataIO NFL ${feed}/${label}`, status: 'FAILED', error: message, httpStatus: httpStatus ? Number(httpStatus) : undefined, retrievedAt });
        return [];
      }
    };
    // SportsDataIO documents NFL DepthCharts and Injuries as separate feeds: depth order
    // represents current coaching intent, while injury/game status represents availability.
    const [teamRows, depthRows, scheduleRows] = await Promise.all([
      load('scores', 'Teams'),
      load('scores', 'DepthCharts'),
      load('scores', 'ScoresByDate', sportsDataDate(slate)),
    ]);
    const schedule = scheduleRows.find((value) => {
      const row = asRecord(value); if (!row) return false;
      const home = normalizeTeamCode(readString(row, ['HomeTeam', 'homeTeam']) ?? '');
      const away = normalizeTeamCode(readString(row, ['AwayTeam', 'awayTeam']) ?? '');
      return home && away && teams.has(home) && teams.has(away);
    });
    const scheduleRecord = asRecord(schedule);
    const scheduleWeek = scheduleRecord ? readIdentifier(scheduleRecord, ['Week', 'week']) : undefined;
    const scheduleSeason = scheduleRecord ? readIdentifier(scheduleRecord, ['Season', 'season']) : undefined;
    const injuryRows = scheduleWeek
      ? await load('stats', 'Injuries', `${scheduleSeason ?? new Date(slate.event.eventDate).getUTCFullYear()}/${scheduleWeek}`, `Injuries/${scheduleSeason ?? new Date(slate.event.eventDate).getUTCFullYear()}/${scheduleWeek}`)
      : [];
    if (!scheduleWeek) diagnostics.push({ provider: 'SportsDataIO NFL stats/Injuries', status: 'EMPTY', error: `No matching NFL schedule event with a provider week was found for ${sportsDataDate(slate)} and teams ${[...teams].join('/')}; injury endpoint was not called.`, retrievedAt });
    const teamKeys = new Map(teamRows.flatMap((value) => { const row = asRecord(value); const id = row ? readIdentifier(row, ['TeamID', 'TeamId', 'teamId']) : undefined; const key = row ? readString(row, ['Key', 'key', 'Abbreviation', 'abbreviation']) : undefined; return id && key ? [[id, normalizeTeamCode(key)] as const] : []; }));
    const records: AvailabilityRecord[] = [];
    const depthByPlayer = new Map<string, { name?: string; providerPlayerId?: string; team?: string; depthOrder?: number; position?: string }>();
    for (const value of depthRows) for (const row of flattenDepthRows(value)) {
      const id = readIdentifier(row, ['PlayerID', 'PlayerId', 'playerId']);
      const name = readString(row, ['Name', 'PlayerName', 'FullName', 'name', 'playerName']);
      const rawTeam = readString(row, ['Team', 'Key', 'team', 'TeamAbbreviation']) ?? readIdentifier(row, ['TeamID', 'TeamId', 'teamId']);
      const team = rawTeam && teamKeys.get(rawTeam) ? teamKeys.get(rawTeam) : rawTeam;
      if (!name && !id) continue;
      const key = id ?? normalizeProviderName(name ?? '');
      depthByPlayer.set(`${key}|${normalizeTeamCode(team)}`, { name, providerPlayerId: id, team, depthOrder: readNumber(row, ['DepthOrder', 'depthOrder']), position: readString(row, ['Position', 'position']) });
    }
    for (const value of injuryRows) {
      const row = asRecord(value); if (!row) continue;
      const id = readIdentifier(row, ['PlayerID', 'PlayerId', 'playerId']);
      const name = readString(row, ['Name', 'PlayerName', 'FullName', 'name', 'playerName']);
      const rawTeam = readString(row, ['Team', 'Key', 'team', 'TeamAbbreviation']) ?? readIdentifier(row, ['TeamID', 'TeamId', 'teamId']);
      const team = rawTeam && teamKeys.get(rawTeam) ? teamKeys.get(rawTeam) : rawTeam;
      if (!name && !id) continue;
      const key = id ?? normalizeProviderName(name ?? '');
      const depth = [...depthByPlayer.entries()].find(([depthKey]) => depthKey.startsWith(`${key}|`))?.[1];
      if (team && !teams.has(normalizeTeamCode(team))) continue;
      const injuryStatus = readString(row, ['InjuryStatus', 'Status', 'status', 'InjuryStatusDescription']) ?? '';
      const rosterStatus = readString(row, ['RosterStatus', 'PlayerStatus', 'ActiveStatus']) ?? '';
      const combined = `${injuryStatus} ${rosterStatus}`;
      const unavailable = /out|inactive|injured reserve|physically unable|suspended|non.?football/i.test(combined);
      const questionable = /questionable|doubtful|probable|limited|day.to.day/i.test(combined);
      const depthOrder = depth?.depthOrder;
      records.push({ playerName: name ?? '', team: team ?? depth?.team, providerPlayerId: id, status: unavailable ? 'OUT' : questionable ? 'PROJECTED' : 'ACTIVE', roleStatus: depthOrder === 1 ? 'EXPECTED_STARTER' : depthOrder && depthOrder > 1 ? 'NOT_STARTER' : 'ROLE_UNCONFIRMED', confirmed: true, updatedAt: retrievedAt, note: `${injuryStatus || rosterStatus || 'No active injury designation'}; depth order ${depthOrder ?? 'not supplied'}.` });
    }
    for (const [key, depth] of depthByPlayer) {
      if (!depth.team || !teams.has(normalizeTeamCode(depth.team))) continue;
      if (records.some((record) => record.providerPlayerId && key.startsWith(`${record.providerPlayerId}|`))) continue;
      if (!depth.name) continue;
      records.push({ playerName: depth.name, team: depth.team, providerPlayerId: depth.providerPlayerId, status: 'ACTIVE', roleStatus: depth.depthOrder === 1 ? 'EXPECTED_STARTER' : depth.depthOrder && depth.depthOrder > 1 ? 'NOT_STARTER' : 'ROLE_UNCONFIRMED', confirmed: true, updatedAt: retrievedAt, note: `SportsDataIO depth chart status; depth order ${depth.depthOrder ?? 'not supplied'}.` });
    }
    const rosterComplete = records.length > 0 && [...teams].every((team) => records.some((record) => normalizeTeamCode(record.team) === team));
    return { source: 'SPORTSDATAIO', retrievedAt, records, confirmedLineupAvailable: false, rosterComplete, diagnostics, note: 'NFL availability combines SportsDataIO Injuries with DepthCharts; depth order is role intent, not game-day inactive confirmation.' };
  }
  private async getCfbRosterSnapshot(slate: ValidatedSlate, signal?: AbortSignal): Promise<AvailabilitySnapshot> {
    const retrievedAt = new Date().toISOString();
    const slateTeams = [...new Set(slate.playerPool.map((player) => normalizeTeamCode(player.team)).filter(Boolean))];
    const teamsPayload = await this.get<unknown>('CFB', 'scores', 'Teams', undefined, signal);
    const teamRows = rowsFromPayload(teamsPayload);
    const teamKeys = new Map<string, string>();
    for (const value of teamRows) {
      const row = asRecord(value); if (!row) continue;
      const key = readString(row, ['Key', 'key']);
      if (!key) continue;
      for (const alias of [
        readString(row, ['Key', 'key']),
        readString(row, ['Abbreviation', 'abbreviation']),
        readString(row, ['ShortDisplayName', 'shortDisplayName']),
        readString(row, ['School', 'school']),
        readString(row, ['Name', 'name']),
        readString(row, ['Team', 'team']),
      ].filter((value): value is string => Boolean(value))) teamKeys.set(normalizeTeamCode(alias), key);
    }
    const records: AvailabilityRecord[] = [];
    const notes: string[] = [];
    let complete = true;
    // The account-accessible CFB roster operation is PlayersByActive. The older
    // PlayerDetailsByTeam operation is listed in legacy client metadata but returns
    // HTTP 404 for this account, so fetch the verified active-player roster once and
    // partition it by the provider's unique team Key.
    const activePlayers = rowsFromPayload(await this.get<unknown>('CFB', 'scores', 'PlayersByActive', undefined, signal));
    for (const slateTeam of slateTeams) {
      const fallbackTeam = teamRows.map((value) => asRecord(value)).find((row) => row && normalizeProviderName(readString(row, ['Abbreviation', 'abbreviation']) ?? '') === normalizeProviderName(slateTeam));
      const providerKey = teamKeys.get(slateTeam) ?? (fallbackTeam ? readString(fallbackTeam, ['Key', 'key']) : undefined);
      if (typeof providerKey !== 'string' || !providerKey) { complete = false; notes.push(`SportsDataIO CFB team key was not resolved for ${slateTeam}.`); continue; }
      const rosterRows = activePlayers.filter((value) => {
        const row = asRecord(value); if (!row) return false;
        const providerTeam = readString(row, ['Team', 'team']);
        return providerTeam ? normalizeTeamCode(providerTeam) === normalizeTeamCode(providerKey) : false;
      });
      if (!rosterRows.length) { complete = false; notes.push(`SportsDataIO CFB roster returned no players for ${slateTeam} (${providerKey}).`); continue; }
      for (const value of rosterRows) {
        const row = asRecord(value); if (!row) continue;
        const playerName = readString(row, ['Name', 'PlayerName', 'FullName', 'name', 'playerName']) ?? fullName(row);
        if (!playerName) continue;
        const injuryStatus = readString(row, ['InjuryStatus', 'injuryStatus', 'Status', 'status']);
        const injuryNotes = readString(row, ['InjuryNotes', 'injuryNotes', 'InjuryNote', 'injuryNote']);
        const status = /out/i.test(injuryStatus ?? '') ? 'OUT' : injuryStatus ? 'PROJECTED' : 'ACTIVE';
        records.push({ playerName, team: slateTeam, providerPlayerId: readIdentifier(row, ['PlayerID', 'PlayerId', 'playerId']), status, roleStatus: 'ROLE_UNCONFIRMED', confirmed: false, updatedAt: retrievedAt, note: injuryStatus ? `SportsDataIO injury status: ${injuryStatus}${injuryNotes ? ` (${injuryNotes})` : ''}. CFB starter role was not provided.` : 'SportsDataIO roster membership verified; CFB starter role was not provided.' });
      }
    }
    return { source: 'SPORTSDATAIO', retrievedAt, records, confirmedLineupAvailable: false, rosterComplete: complete && slateTeams.length > 0, note: notes.length ? notes.join(' ') : `SportsDataIO CFB roster and injury records scoped to ${slateTeams.join('/')}. CFB depth charts/starting lineups are not provided by this feed.` };
  }
  /**
   * Real season-to-date box-score totals (verified live against this account -- unlike
   * `PlayerGameProjectionStatsByDate`, which returns SportsDataIO's premium/gated projection
   * product and comes back obfuscated on a free-trial key, `PlayerSeasonStats` numeric fields
   * are the account's own real, ungated stats). Used as the projection basis for MLB/NBA/NFL --
   * see projectionInputs.ts's deriveSeasonBasedInputs for how season totals become per-game rates.
   */
  async getSeasonStats(sport: Sport, seasonParam: string, signal?: AbortSignal): Promise<Record<string, unknown>[]> {
    // WNBA exposes PlayerSeasonStats under the scores subfeed. The other supported
    // season-stat routes used here are under stats (verified against the published
    // OpenAPI schemas and the configured account).
    const feed = sport === 'WNBA' ? 'scores' : 'stats';
    const payload = await this.get<unknown>(sport, feed, 'PlayerSeasonStats', seasonParam, signal);
    if (!Array.isArray(payload)) return [];
    return payload.flatMap((value) => (value && typeof value === 'object' ? [value as Record<string, unknown>] : []));
  }
  /** Final MLB player game stats. The result is useful for role/workload diagnostics;
   * it must be filtered to games before the slate lock before historical projection use. */
  async getMlbPlayerGameLogs(season: string, playerId: string | number, count = 10, signal?: AbortSignal): Promise<Record<string, unknown>[]> {
    return rowsFromPayload(await this.get<unknown>('MLB', 'stats', 'PlayerGameStatsBySeason', `${encodeURIComponent(season)}/${encodeURIComponent(String(playerId))}/${Math.max(1, Math.min(25, Math.floor(count)))}`, signal)).flatMap((value) => { const row = asRecord(value); return row ? [row] : []; });
  }
  /** NBA's documented season/player game-log feed supplies minutes and starts per game. */
  async getNbaRecentPlayerGameLogs(season: string, playerId: string | number, count = 10, signal?: AbortSignal): Promise<NbaRecentPlayerGame[]> {
    const boundedCount = Math.max(1, Math.min(25, Math.floor(count)));
    const rows = rowsFromPayload(await this.get<unknown>('NBA', 'stats', 'PlayerGameStatsBySeason', `${encodeURIComponent(season)}/${encodeURIComponent(String(playerId))}/${boundedCount}`, signal));
    return rows.flatMap((value) => {
      const row = asRecord(value); if (!row) return [];
      const minutes = readNumber(row, ['Minutes', 'minutes']);
      const id = readIdentifier(row, ['PlayerID', 'PlayerId', 'playerId']);
      const name = readString(row, ['Name', 'PlayerName', 'FullName', 'name']);
      const team = readString(row, ['Team', 'TeamName', 'TeamAbbr', 'TeamKey']);
      const date = readString(row, ['DateTime', 'Day', 'Date']);
      if (minutes === undefined || minutes < 0 || (!id && !name)) return [];
      const startedValue = readBoolean(row, ['Started', 'IsStarter']);
      const starts = readNumber(row, ['GamesStarted', 'PitchingGamesStarted']);
      return [{ ...(id ? { playerId: id } : {}), ...(name ? { name } : {}), ...(team ? { team } : {}), ...(readIdentifier(row, ['GameID', 'GameId']) ? { gameId: readIdentifier(row, ['GameID', 'GameId']) } : {}), ...(date ? { date } : {}), minutes, ...(startedValue !== undefined || starts !== undefined ? { started: startedValue ?? starts! > 0 } : {}) }];
    });
  }
  /** SportsDataIO MLB schedule rows include forecast temperature, wind and conditions. */
  async getMlbGameWeather(date: string, signal?: AbortSignal): Promise<SportsDataIoGameWeather[]> {
    const rows = rowsFromPayload(await this.get<unknown>('MLB', 'scores', 'GamesByDate', date, signal));
    return rows.flatMap((value) => {
      const row = asRecord(value); if (!row) return [];
      return [{ gameId: readIdentifier(row, ['GameID', 'GameId']), homeTeam: readString(row, ['HomeTeam']), awayTeam: readString(row, ['AwayTeam']), homeProbablePitcherId: readIdentifier(row, ['HomeTeamProbablePitcherID']), awayProbablePitcherId: readIdentifier(row, ['AwayTeamProbablePitcherID']), homeProbablePitcher: readString(row, ['HomeTeamStartingPitcher']), awayProbablePitcher: readString(row, ['AwayTeamStartingPitcher']), homeOpener: readBoolean(row, ['HomeTeamOpener']), awayOpener: readBoolean(row, ['AwayTeamOpener']), temperatureLow: readNumber(row, ['ForecastTempLow']), temperatureHigh: readNumber(row, ['ForecastTempHigh']), windSpeed: readNumber(row, ['ForecastWindSpeed']), windDirection: readString(row, ['ForecastWindDirection']), description: readString(row, ['ForecastDescription']) }];
    });
  }
  /** WNBA exposes final player minutes nested in its final box-score feed. This bounded
   * lookback uses only dates strictly before the slate date, preventing same-day/future leakage. */
  async getWnbaRecentMinutes(eventDate: string, lookbackDays = 28, signal?: AbortSignal): Promise<WnbaRecentPlayerMinutes[]> {
    const target = new Date(`${eventDate.slice(0, 10)}T00:00:00.000Z`);
    if (!Number.isFinite(target.getTime())) return [];
    const dates = Array.from({ length: Math.max(1, Math.min(45, Math.floor(lookbackDays))) }, (_, index) => {
      const day = new Date(target); day.setUTCDate(day.getUTCDate() - index - 1); return day.toISOString().slice(0, 10);
    });
    const byPlayer = new Map<string, { playerId?: string; name?: string; team?: string; minutes: number[] }>();
    // Keep request concurrency modest; the provider's published interval is one minute
    // for box scores, and empty dates are expected during the off-season.
    for (let index = 0; index < dates.length; index += 4) {
      const batches = await Promise.all(dates.slice(index, index + 4).map(async (date) => {
        try { return rowsFromPayload(await this.get<unknown>('WNBA', 'scores', 'BoxScores', date, signal)); }
        catch { return []; }
      }));
      for (const boxScores of batches) for (const boxValue of boxScores) {
        const box = asRecord(boxValue); if (!box) continue;
        for (const playerValue of rowsFromPayload(box.PlayerGames)) {
          const player = asRecord(playerValue); if (!player) continue;
          const id = readIdentifier(player, ['PlayerID', 'PlayerId', 'playerId']);
          const name = readString(player, ['Name', 'PlayerName', 'name']);
          const team = readString(player, ['Team', 'team', 'TeamAbbreviation']);
          const minutes = readNumber(player, ['Minutes', 'minutes']);
          if ((!id && !name) || minutes === undefined || minutes < 0) continue;
          const key = id ?? `${normalizeProviderName(name ?? '')}|${normalizeTeamCode(team ?? '')}`;
          const row = byPlayer.get(key) ?? { playerId: id, name, team, minutes: [] };
          row.minutes.push(minutes); byPlayer.set(key, row);
        }
      }
    }
    return [...byPlayer.values()].map((row) => ({ ...(row.playerId ? { playerId: row.playerId } : {}), ...(row.name ? { name: row.name } : {}), ...(row.team ? { team: row.team } : {}), minutes: row.minutes.slice(0, 10) }));
  }
  async getGolfTournamentProjectionInputs(slate: ValidatedSlate, signal?: AbortSignal): Promise<GolfProjectionRefresh> {
    const season = String(new Date(slate.event.eventDate).getUTCFullYear());
    const tournaments = rowsFromPayload(await this.getGolf<unknown>('Tournaments', season, signal));
    const slateNames = [slate.contest.name, slate.event.name].map(normalizeProviderName).filter((name) => name.length >= 5);
    const tournamentRows = tournaments.map(asRecord).filter((row): row is Record<string, unknown> => Boolean(row));
    const eventDate = new Date(slate.event.eventDate).toISOString().slice(0, 10);
    const dateMatches = preferCoveredGolfTournaments(tournamentRows.filter((row) => tournamentMatchesDate(row, eventDate)));
    const namedMatches = preferCoveredGolfTournaments(tournamentRows.filter((row) => {
      const name = normalizeProviderName(readString(row, ['Name', 'name']) ?? '');
      // Contest names often say only "PGA TOUR Showdown"; retain title matching when
      // the event carries a meaningful tournament name, but use schedule dates otherwise.
      return name.length >= 5 && slateNames.some((candidate) => candidate.includes(name) || name.includes(candidate));
    }));
    const candidates = dateMatches.length ? dateMatches : namedMatches;
    const tournament = candidates.length === 1 ? candidates[0] : undefined;
    if (!tournament) {
      const reason = candidates.length > 1 ? `multiple SportsDataIO Golf tournaments matched date/name (${candidates.map((row) => readString(row, ['Name', 'name']) ?? 'unnamed').join(', ')})` : `no SportsDataIO Golf tournament matched slate date ${eventDate} or event name`;
      return { rows: [], warning: `${reason} for DraftKings contest "${slate.contest.name}" in season ${season}; tournament-specific Golf inputs were not available.` };
    }
    const tournamentId = readIdentifier(tournament, ['TournamentID', 'TournamentId', 'tournamentId']);
    if (!tournamentId) return { rows: [], warning: `SportsDataIO Golf matched tournament "${readString(tournament, ['Name', 'name']) ?? 'unknown'}" but returned no TournamentID.` };
    const projectionRows = rowsFromPayload(await this.getGolf<unknown>('PlayerTournamentProjectionStats', tournamentId, signal));
    const rounds = Array.isArray(tournament.Rounds) ? tournament.Rounds : [];
    const totalRounds = rounds.length || 4;
    if (!projectionRows.length) return { rows: [], tournamentName: readString(tournament, ['Name', 'name']), warning: `SportsDataIO Golf matched tournament "${readString(tournament, ['Name', 'name']) ?? tournamentId}" but returned no PlayerTournamentProjectionStats rows.` };
    let playersById = new Map<string, Record<string, unknown>>();
    let playerCatalogWarning = '';
    try {
      playersById = new Map(rowsFromPayload(await this.getGolf<unknown>('Players', undefined, signal)).flatMap((value) => {
        const row = asRecord(value);
        const id = row && readIdentifier(row, ['PlayerID', 'PlayerId', 'playerId']);
        return row && id ? [[id, row] as const] : [];
      }));
    } catch (error) {
      playerCatalogWarning = error instanceof Error ? ` Golf player-ID crosswalk unavailable: ${error.message}` : ' Golf player-ID crosswalk unavailable.';
    }
    const rows = projectionRows.flatMap((value) => {
      const row = asRecord(value); if (!row) return [];
      const birdies = readNumber(row, ['Birdies', 'birdies']);
      const eagles = readNumber(row, ['Eagles', 'eagles']);
      const bogeys = readNumber(row, ['Bogeys', 'bogeys']);
      const pars = readNumber(row, ['Pars', 'pars']);
      if (![birdies, eagles, bogeys, pars].every((number) => number !== undefined)) return [];
      // PlayerTournamentProjectionStats are event totals. Convert to per-round rates;
      // Showdown consumes one round while Classic consumes the event's remaining rounds.
      const roundsRemaining = slate.contest.format === 'SHOWDOWN' ? 1 : totalRounds;
      const playerId = readIdentifier(row, ['PlayerID', 'PlayerId', 'playerId']);
      const player = playerId ? playersById.get(playerId) : undefined;
      return [{ ...row, ...(player ? { DraftKingsPlayerID: player.DraftKingsPlayerID ?? player.DraftKingsPlayerId, DraftKingsName: player.DraftKingsName } : {}), birdiesPerRound: birdies! / totalRounds, eaglesPerRound: eagles! / totalRounds, bogeysPerRound: bogeys! / totalRounds, parsPerRound: pars! / totalRounds, roundsRemaining }];
    });
    return { rows, tournamentName: readString(tournament, ['Name', 'name']), warning: rows.length ? `Golf inputs sourced from SportsDataIO tournament projections for ${readString(tournament, ['Name', 'name']) ?? tournamentId}.${playerCatalogWarning}` : `SportsDataIO Golf tournament projections for ${readString(tournament, ['Name', 'name']) ?? tournamentId} did not contain all required scoring fields.${playerCatalogWarning}` };
  }
}

// MLB/NBA/CFB accept a bare year; NFL requires the season-type suffix ('REG' = regular season).
export function seasonParamFor(sport: Sport, eventDate: string, yearOffset = 0): string {
  const year = new Date(eventDate).getUTCFullYear() + yearOffset;
  return sport === 'NFL' ? `${year}REG` : String(year);
}

export interface SportsDataIoResearchProviderOptions { client: SportsDataIoClient; feed?: string; resource?: string; tier?: SourceTier; }
export class SportsDataIoResearchProvider implements ResearchSourceProvider {
  readonly name = 'SportsDataIO';
  readonly tier: SourceTier;
  private readonly options: SportsDataIoResearchProviderOptions;
  constructor(options: SportsDataIoResearchProviderOptions) { this.options = options; this.tier = options.tier ?? 2; }
  async fetch(input: { slate: ValidatedSlate; plan: ResearchPlan; signal?: AbortSignal }): Promise<ResearchArticle[]> {
    const resource = this.options.resource ?? (input.slate.sport === 'NFL' ? 'ScoresByDate' : 'GamesByDate');
    const payload = await this.options.client.get<unknown>(input.slate.sport, this.options.feed ?? 'scores', resource, sportsDataDate(input.slate), input.signal);
    return (Array.isArray(payload) ? payload : []).slice(0, 20).map((row, index) => ({ title: `${input.slate.sport} schedule context ${index + 1}`, sourceName: this.name, sourceTier: this.tier, summary: summarize(row), tags: [input.slate.sport, 'sportsdataio'] }));
  }
}
function sportsDataDate(slate: ValidatedSlate): string { const date = new Date(slate.event.eventDate); if (slate.sport === 'MLB' && date.getUTCHours() < 6) date.setUTCDate(date.getUTCDate() - 1); return date.toISOString().slice(0, 10); }
function summarize(value: unknown): string { if (!value || typeof value !== 'object') return String(value ?? 'No schedule context returned.'); const row = value as Record<string, unknown>; const fields = ['Status', 'Date', 'HomeTeam', 'AwayTeam', 'HomeTeamName', 'AwayTeamName', 'VenueName', 'StadiumDetails']; const parts = fields.flatMap((field) => typeof row[field] === 'string' || typeof row[field] === 'number' ? [`${field}: ${row[field]}`] : []); return parts.join('; ') || JSON.stringify(value).slice(0, 500); }
function rowsFromPayload(payload: unknown): unknown[] {
  if (Array.isArray(payload)) return payload;
  if (!payload || typeof payload !== 'object') return [];
  const record = payload as Record<string, unknown>;
  for (const key of ['data', 'results', 'teams', 'players', 'athletes']) if (Array.isArray(record[key])) return record[key];
  return [];
}
function tournamentMatchesDate(row: Record<string, unknown>, eventDate: string): boolean {
  const rounds = Array.isArray(row.Rounds) ? row.Rounds : [];
  if (rounds.some((value) => { const round = asRecord(value); return round && golfDateOnly(readString(round, ['Day', 'Date', 'day', 'date'])) === eventDate; })) return true;
  const start = golfDateOnly(readString(row, ['StartDate', 'startDate']));
  const end = golfDateOnly(readString(row, ['EndDate', 'endDate']));
  return Boolean(start && end && start <= eventDate && eventDate <= end);
}
function golfDateOnly(value: string | undefined): string | undefined { return value?.match(/^\d{4}-\d{2}-\d{2}/)?.[0]; }
function preferCoveredGolfTournaments(rows: Record<string, unknown>[]): Record<string, unknown>[] {
  const covered = rows.filter((row) => row.Covered === true || row.Covered === 'true');
  return covered.length ? covered : rows.filter((row) => row.Covered !== false && row.Covered !== 'false');
}
function flattenDepthRows(value: unknown, inheritedTeam?: string): Record<string, unknown>[] {
  const row = asRecord(value); if (!row) return [];
  const ownTeam = readString(row, ['Team', 'Key', 'team', 'TeamAbbreviation']) ?? readIdentifier(row, ['TeamID', 'TeamId', 'teamId']) ?? inheritedTeam;
  const normalized = ownTeam && !readString(row, ['Team', 'team', 'TeamAbbreviation']) ? { ...row, Team: ownTeam } : row;
  return [normalized].concat(...['Offense', 'Defense', 'SpecialTeams', 'offense', 'defense', 'specialTeams'].map((key) => Array.isArray(row[key]) ? row[key].flatMap((item) => flattenDepthRows(item, ownTeam)) : []));
}
function asRecord(value: unknown): Record<string, unknown> | undefined { return value && typeof value === 'object' && !Array.isArray(value) ? value as Record<string, unknown> : undefined; }
function readString(record: Record<string, unknown>, keys: string[]): string | undefined { for (const key of keys) if (typeof record[key] === 'string' && String(record[key]).trim()) return String(record[key]).trim(); return undefined; }
function readIdentifier(record: Record<string, unknown>, keys: string[]): string | undefined { for (const key of keys) { const value = record[key]; if ((typeof value === 'string' || typeof value === 'number') && String(value).trim()) return String(value).trim(); } return undefined; }
function readNumber(record: Record<string, unknown>, keys: string[]): number | undefined { for (const key of keys) { const value = record[key]; if (typeof value === 'number' && Number.isFinite(value)) return value; if (typeof value === 'string' && Number.isFinite(Number(value))) return Number(value); } return undefined; }
function readBoolean(record: Record<string, unknown>, keys: string[]): boolean | undefined { for (const key of keys) { const value = record[key]; if (typeof value === 'boolean') return value; if (typeof value === 'number' && (value === 0 || value === 1)) return value === 1; if (typeof value === 'string' && /^(true|false)$/i.test(value)) return value.toLowerCase() === 'true'; } return undefined; }
function fullName(record: Record<string, unknown>): string | undefined { const first = readString(record, ['FirstName', 'firstName']); const last = readString(record, ['LastName', 'lastName']); return first && last ? `${first} ${last}` : first ?? last; }
